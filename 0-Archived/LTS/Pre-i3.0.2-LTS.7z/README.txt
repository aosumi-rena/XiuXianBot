EN

1. This is a free (and shittily made) bot emulator, if you purchased for it, you have been scammed, please ask for refunds! Project Link: https://github.com/aosumi-rena/XiuXianBot/tree/main
2. Make sure you have installed Python 3.10+, MongoDB, and those packages stated in requirements.txt before running this bot
3. Fill in your Discord Bot Token and admin_ids in ./bot.py, as well as admin_ids in ./commands/admin/*.py before running this bot
4. Remeber to fill in links to ToS (Terms of Service), privacy policy, adding bot and top.gg voting in ./commands/general/help.py
5. Please also fill in admin contact info in ./commands/game/contact.py so that users can contact you if bug occured.
6. Once everything checked, run ./bot.py to start the bot and have fun!

For ./textmaps/
1. CHT localisation may be appearing in some files, but it probably wont fully work if you add CHT.json in the ./textmaps/, since its not tested
2. A sample code is added in the codes.json, you may use Code_Generation.html to generate more codes if needed
3. Items has almost no use, thus shop and shop.json is also useless

==============================
CHS

1. 这是一个免费（烂活）软件，如果你是通过购买的方式获得的此套文件，说明你被骗了，请立即退款！仓库链接：https://github.com/aosumi-rena/XiuXianBot/tree/main
2. 在开始运行前，请确保你已下载并安装了Python 3.10+ 环境、MongoDB、及requirements.txt里的package。
3. 在开始运行前，请确保必要的变量已被修改，这包括Discord Bot Token, admin_ids (./bot.py 及 ./commands/admin/*.py)
4. 请记得在 ./commands/general/help.py 中添加条款、隐私政策、添加Bot和top.gg投票的链接
5. 请记得在 ./commands/game/contact.py 中添加联系信息，以便玩家能够及时联系Bot管理员
6. 全部确认后，运行 ./bot.py 启动机器人，祝你好运！

关于 ./textmaps/
1a. 繁中(CHT)的本地化信息可能有在部分代碼中出現，但添加CHT.json后可能什麽都不會發生，因爲暫時沒有經過測試，也沒有著重開發過。
1b. 繁中(CHT)的本地化信息可能有在部分代码中出现，但添加CHT.json后可能什么都不会发生，因为暂时还没经过测试，也没着重开发。
2. codes.json中已预添加了一个示例兑换码，你也可以使用Code_Generation.html生成更多的兑换码
3. 物品暂时几乎没有用，所以商店功能和shop.json也没用